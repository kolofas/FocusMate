# backend/services_tasks.py
from typing import Optional
from sqlalchemy.orm import Session
from . import models
from .services import ParsedInbox
from .enums import TaskSource, TaskStatus
from .time_utils import to_utc
from .utils.tags import canonicalize_tags

MAX_DESC_LEN = 4000  # единая константа


def create_task_from_parsed(db: Session,
                            parsed: ParsedInbox,
                            *,
                            source: TaskSource,
                            status: TaskStatus = TaskStatus.INBOX,
                            raw_text: Optional[str] = None,
                            ) -> models.Task:
    """
    Создаёт Task из ParsedInbox. Источник и статус приходят снаружи.
    Нормализует title/tags и переводит дедлайн в UTC.
    """
    title = (parsed.title or "").strip()
    if not title:
        raise ValueError("empty title")

    description = (raw_text or parsed.raw or "")[:MAX_DESC_LEN]

    deadline_utc = to_utc(parsed.deadline_local) if getattr(parsed, "deadline_local", None) else None

    tags = canonicalize_tags(parsed.tags or [])

    task = models.Task(
        title=title,
        description=description,
        source=source.value,
        status=status.value,
        deadline=deadline_utc,
        tags=tags,
    )

    db.add(task)
    return task
