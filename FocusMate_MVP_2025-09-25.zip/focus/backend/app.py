from fastapi import FastAPI
from .routers.health import router as health_router
from .routers.tasks import router as tasks_router
from .routers.inbox import router as inbox_router
from .models import Base
from .core import engine

app = FastAPI(title="FocusMate (MVP)")
app.include_router(health_router, prefix="/health", tags=["health"])
app.include_router(inbox_router, prefix="/inbox", tags=["inbox"])
app.include_router(tasks_router, prefix="/tasks", tags=["tasks"])

Base.metadata.create_all(bind=engine)